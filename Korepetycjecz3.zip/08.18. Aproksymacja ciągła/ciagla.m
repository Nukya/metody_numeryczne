%%% aproksymacja ciągła

clear all

x = 1:0.01:2;
for i=1:length(x)
    y1(i) = f(x(i));
    y2(i) = F(x(i));
end

plot(x,y1,'k-',x,y2,'b-')
grid on
xlabel('x')
ylabel('y')

function ans = f(x)
    ans = 1/x;
end

function ans = F(x)
    ans = (28*log(2)-18)+(12-18*log(2))*x;
end