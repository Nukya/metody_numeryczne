%%% aproksymacja dyskretna trygonometryczna %%%

clear all 

xi = 0:0.6:1.2;
yi = [0.08 0.27 0.1];

% xi = 0:0.2:1.2;
% yi = [0.08 0.2 0.25 0.27 0.22 0.15 0.1];

n = length(xi)-1;
c = C(n,xi(1),xi(n+1))
res = coeff(xi,yi,c)

x = xi(1):0.01:xi(n+1);
y1 = T1(x,c,res);
y2 = T2(x,c,res);

plot(x,y1,'r-',x,y2,'b-',xi,yi,'k.','MarkerSize',15)
grid on

bl1 = blad(xi,yi,@T1,c,res)
bl2 = blad(xi,yi,@T2,c,res)

function ans = C(n,a,b)
    h = (b-a)/n;
    l = (n+1)*h/2;
    ans = pi/l;
end

function ans = coeff(xi,yi,c)
    n = length(xi)-1;
    a0 = sum(yi)/(n+1);
    a1 = 2*sum(yi.*cos(c*xi))/(n+1);
    b1 = 2*sum(yi.*sin(c*xi))/(n+1);
    a2 = 2*sum(yi.*cos(2*c*xi))/(n+1);
    b2 = 2*sum(yi.*sin(2*c*xi))/(n+1);
    ans = [a0 a1 b1 a2 b2];
end

function ans = T1(x,c,res)
    ans = res(1) + res(2)*cos(c*x) + res(3)*sin(c*x);
end

function ans = T2(x,c,res)
    ans = res(1) + res(2)*cos(c*x) + res(3)*sin(c*x) + res(4)*cos(2*c*x) + res(5)*sin(2*c*x);
end

function ans = blad(xi,yi,T,c,res)
    tmp = 0;

    for i=1:length(xi)
        tmp = tmp + (yi(i) - T(xi(i),c,res))^2;
    end

    ans = sqrt(tmp/length(xi));
end