function [dy] = poch4(y,t,p)

R1 = p.R1;
R2 = p.R2;
C = p.C;
L1 = p.L1;
L2 = p.L2;


M = p.M;

D1 = L1/M - M/L2;
D2 = M/L1 - L2/M;

dy(1) = -R1/M/D1 * y(1) +R2/L2/D1 * y(2)  -1/M/D1 * y(3) +1/M/D1 * e(t,p.f);
dy(2) = -R1/L1/D2 * y(1) +R2/M/D2 * y(2)  -1/L1/D2 * y(3) +1/L1/D2 * e(t,p.f);
dy(3) = 1/C*y(1);

end

