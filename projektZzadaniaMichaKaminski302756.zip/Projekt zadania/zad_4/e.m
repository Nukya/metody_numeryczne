%Funkcja pomocnicza została zmodyfikowana i urposzczona do tego zadania.
%Przedstawia tylko jedno wymuszenie.
function [u] = e(t,f)
% z treści zadania.
u = 100*sin(2*pi*f*t);
end

