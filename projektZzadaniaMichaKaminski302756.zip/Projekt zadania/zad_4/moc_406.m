function parabole = moc_406(p,f)


%czas i czestotliwosc
t_k = 30;
p.f = f;

% nie mniej niż 600 przedziałów
t = linspace(0,t_k,max(30*p.f*30,601));
h = t(2)-t(1);

y_ul = zeros(length(t),3);

for i = 1:(length(t)-1)
    pomoc = y_ul(i,:) + h/2*poch4(y_ul(i,:),t(i),p);
    y_ul(i+1,:) = y_ul(i,:) + h*poch4(pomoc,t(i)+h/2,p);
end

i_1 = y_ul(:,1);
i_2 = y_ul(:,2);
podcal_1 = i_1.^2*p.R1;
podcal_2 = i_2.^2*p.R2;
podcal = podcal_1+  podcal_2;
% wzor na parabole jak w cw.3
parabole = 1/3*h*(podcal(1)+4*sum(podcal(2:2:end-1)) +2*sum(podcal(3:2:end-2)) +podcal(end));
%pomniejszone o 406W
parabole = parabole/30 - 406;
end

