clear
close all
clc

p.R1 = 0.1;
p.R2 = 10;
p.C = 0.5;
p.L1 = 3;
p.L2 = 5;
p.M = 0.8;

disp(p);

% częstotliwość
x = logspace(-2,0,100);  
y = x*0;

pp = @(x) moc_406(p,x);

h = ones(1,6)* 0.0005;

pochodna = zeros(length(x),length(h));

for j = 1:6
    h(j) = h(1)/2^(j-1);
    for i = 1:length(x)
        pochodna(i,j) = (pp(x(i)+h(j))-pp(x(i)))/h(j);
    end
end

figure;
semilogx(x,pochodna);
legend(num2str(h'));
grid on;


pochodna_roznica = zeros(length(x),length(h)-1);

for i = 1:length(x)
    for j = 2:length(h)
        pochodna_roznica(i,j-1) = abs(pochodna(i,j)-pochodna(i,j-1))./max(abs([pochodna(i,j),pochodna(i,j-1)]));
    end
end


figure;
semilogx(x,pochodna_roznica*100);
legend([num2str(h(1:end-1)') + ["  ---  ";"  ---  ";"  ---  ";"  ---  ";"  ---  "] + num2str(h(2:end)')],'location','best');
grid on;



