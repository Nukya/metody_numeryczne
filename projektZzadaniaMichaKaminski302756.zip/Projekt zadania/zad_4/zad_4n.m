clear
close all
clc

disp('#################   METODA   QUASI-NEWTONA   #################');
for wariant = ['1' '2' '3']
    
    switch wariant
        case '1'
            p.R1 = 0.1;
            p.R2 = 10;
            p.C = 0.5;
            p.L1 = 3;
            p.L2 = 5;
            p.M = 0.8;
        case '2'
            p.R1 = 5;
            p.R2 = 5;
            p.C = 0.5;
            p.L1 = 3;
            p.L2 = 2;
            p.M = 0.6;
        case '3'
            p.R1 = 0.1;
            p.R2 = 2;
            p.C = 0.8;
            p.L1 = 7;
            p.L2 = 7;
            p.M = 0.2;
    end
    
    disp(['     WARIANT ' wariant]);
    disp(p);
    
    f = logspace(-2,0,100);  % częstotliwość
    
    pp = @(x) moc_406(p,x);
    
    x = logspace(-2,0,100);
    y = f*0;
    for i = 1:length(f)
        y(i) = moc_406(p,f(i));
    end
    
    A = [];
    B = [];
    C = [];
    
    for i = 1:(length(x)-1)
        if y(i)*y(i+1)<=0
            A = [A,x(i)];
            B = [B,x(i+1)];
        end
    end
    
    
    for j = 1:length(A)
        
        a = A(j);
        b = B(j);
        c = (a+b)/2;
        y_c = pp(c);
        i = 0;
        
        while i<1000 && abs(y_c)>=1e-5
            dp_c = (y_c - pp(c-1e-5))/1e-5;
            c = c - y_c/dp_c;
            y_c = pp(c);
            i = i+1;
        end
        C = [C,c];
        
        
        disp(['########### Przedział ' num2str(j) ' ###########']);
        disp(['Ilość iteracji: ' num2str(i)]);
        disp(['Ilość obliczeń mocy: ' num2str(2*i+1)]);
        disp(['Wynik: ' num2str(c)]);
        disp(['Moc - 406 dla wyniku: ' num2str(y_c)]);
        disp(newline);
    end
    
    figure;
    semilogx(x,y);
    grid on;
    hold on;
    yline(0);
    semilogx(C,0,'o');
    hold off;
    
    
end