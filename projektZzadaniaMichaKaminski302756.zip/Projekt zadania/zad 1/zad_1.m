% zwalnia pamiec z wszystkich zapisanych zmiennych
clear;
% Zamyka wszystkie włączone wykresy
close all;
% Usuwa  caly tekst z Command Window
clc;


%Głowna pętla odpowiedzialna za wykonanie wszystkich wymuszeń o 
% odpowiednich parametrach, wykreslanie wykresów, oblcizenia dla metod 
% eulera   
for wymuszenie = ['1','2','3','4']

    %Dane podane w tresci zadania
    p.R1 = 0.1;
    p.R2 = 10;
    p.C = 0.5;
    p.L1 = 3;
    p.L2 = 5;
    p.M = 0.8;
    
    %Instrukcja warunkowa switch z paramterami dla odpowiednich wymuszeń
    switch wymuszenie
        case '1'
            p.e = '1';            
            t_k = 30;
            %współczynnik h do metody Eulera
            h = 0.1;
        case '2'
            p.e = '2';
            t_k = 30;
            h = 0.09;
        case '3'
            p.e = '3';
            t_k = 30;
            h = 0.001;
        case '4'
            p.e = '4';
            t_k = 30;
            h = 0.0095;
    end

    %czas z krokiem
    t = [0:h:t_k];   
    y = zeros(length(t),3);
    
    % Metoda Eulera
    for i = 1:(length(t)-1)
        y(i+1,:) = y(i,:) + h*poch(y(i,:),t(i),p);
    end
    
    %Wykreślanie Wykresu dla napięcia
    figure
    plot(t,e(t,p.e));
    hold on;
    plot(t,y(:,3));
    legend(["e" "u_c"],'Location','northeast');
    ylabel('U[V]');
    xlabel('t(s)');
    hold off;
    saveas(gca,['euler_nap_' wymuszenie '.png']);
    
    %Wykreślanie Wykresu dla natężenia
    figure
    plot(t,y(:,1));
    hold on;
    plot(t,y(:,2));
    legend(["i_1" "i_2"],'Location','northeast');
    ylabel('I[A]');
    xlabel('t(s)');
    hold off;
    saveas(gca,['euler_nat_' wymuszenie '.png']);
    
    
    y_ul = zeros(length(t),3);
    
    %Ulepszona Metoda Eulera
    for i = 1:(length(t)-1)
        pomoc = y_ul(i,:) + h/2*poch(y_ul(i,:),t(i),p);
        y_ul(i+1,:) = y_ul(i,:) + h*poch(pomoc,t(i)+h/2,p);
    end
    
    %Wykreślanie Wykresu dla napięcia
    figure
    plot(t,e(t,p.e));
    hold on; 
    plot(t,y_ul(:,3));   
    legend(["e" "u_c"],'Location','northeast');
    ylabel('U[V]');
    xlabel('t(s)');
    hold off;
    saveas(gca,['ulep_nap_' wymuszenie '.png']);
    
    %Wykreślanie Wykresu dla natężenia
    figure
    plot(t,y_ul(:,1));
    hold on;
    plot(t,y_ul(:,2));
    legend(["i_1" "i_2"],'Location','northeast');
    ylabel('I[A]');
    xlabel('t(s)');
    hold off;
    saveas(gca,['ulep_nat_' wymuszenie '.png']);
    
end






