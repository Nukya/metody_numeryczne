clear
close all
clc

warning('off');
wyniki_par = [];
wyniki_pr = [];
for krok = ["zgrubny","gesty"]
    for wymuszenie = ['1','2','3','4','7']%
        for rodzaj = ["a" "b"]  % a - stałe M, b - nieliniowe M
            
            p.R1 = 0.1;
            p.R2 = 10;
            p.C = 0.5;
            p.L1 = 3;
            p.L2 = 5;
            p.M = 0.8;
            
            switch wymuszenie
                case '1'
                    p.e = '1';
                    t_k = 30;
                    h = 0.001;
                case '2'
                    p.e = '2';
                    t_k = 30;
                    h = 0.001;
                case '3'
                    p.e = '3';
                    t_k = 30;
                    h = 0.001;
                case '4'
                    p.e = '4';
                    t_k = 30;
                    h = 0.001;
                case '7'
                    p.e = '7';
                    t_k = 30;
                    h = 0.001;
            end
            
            if krok == "zgrubny"
                h = h*10;
            end
            
            t = [0:h:t_k];
            
            
            y_ul = zeros(length(t),3);
            
            for i = 1:(length(t)-1)
                pomoc = y_ul(i,:) + h/2*poch3(y_ul(i,:),t(i),p,rodzaj);
                y_ul(i+1,:) = y_ul(i,:) + h*poch3(pomoc,t(i)+h/2,p,rodzaj);
            end
            
            i_1 = y_ul(:,1);
            i_2 = y_ul(:,2);
            podcal_1 = i_1.^2*p.R1;
            podcal_2 = i_2.^2*p.R2;
            podcal = podcal_1+  podcal_2;
            
            % wykres
            if krok == "zgrubny"
                figure('visible','off');
                if rodzaj == "a"
                    title(['Moc dla wym. nr ' wymuszenie ', sprzężenie/;e']);
                end
                
                if rodzaj == "b"
                    title(['Moc dla wym. nr ' wymuszenie ', sprzężenie nieliniowe']);
                end
                
                hold on;
                plot(t,podcal_1);
                plot(t,podcal_2);
                plot(t,podcal);
                legend(["Moc opornik 1","Moc opornik 2","Moc łączna oporników"])
                hold off;
                saveas(gca,['podcalkowa_' wymuszenie '_rodzaj_' char(rodzaj) '.png']);
            end
            
            % całka
            prost = sum(podcal(1:end-1))*h;
            parabole = 1/3*h*(podcal(1)+4*sum(podcal(2:2:end-1)) +2*sum(podcal(3:2:end-2)) +podcal(end));
            wyniki_par = [wyniki_par;krok,wymuszenie,rodzaj,parabole];
            wyniki_pr = [wyniki_pr;krok,wymuszenie,rodzaj,prost];
        end
        
    end
end