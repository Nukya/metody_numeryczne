function [dy] = poch3(y,t,p,rodzaj)

R1 = p.R1;
R2 = p.R2;
C = p.C;
L1 = p.L1;
L2 = p.L2;



switch rodzaj
    case "a"
        pomoc = @(x) p.M;
    case "b"
        pomoc = @(x) sklejane(x);
end

M = pomoc(abs(e(t,p.e) - y(3) - y(1)*R1));

D1 = L1/M - M/L2;
D2 = M/L1 - L2/M;

dy(1) = -R1/M/D1 * y(1) +R2/L2/D1 * y(2)  -1/M/D1 * y(3) +1/M/D1 * e(t,p.e);
dy(2) = -R1/L1/D2 * y(1) +R2/M/D2 * y(2)  -1/L1/D2 * y(3) +1/L1/D2 * e(t,p.e);
dy(3) = 1/C*y(1);

end

