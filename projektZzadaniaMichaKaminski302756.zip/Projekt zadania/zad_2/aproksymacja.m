%Funkcja pomocnicza dla aproksymacji wielomianowej. 
function y = aproksymacja(x,stopien)
%Tabela nacieacia Ul1 na indukcyjnosci L1 w obwodzie pierwotnym zgodnie z
%założeniem 
u = [20 50 100 150 200 250 280 300].';
M = [0.46 0.64 0.78 0.68 0.44 0.23 0.18 0.18].';

% stopień aproksymacji + 1
n = stopien+1; 

%Zaimplemetnowany wzór z podręcznika 6.2.6, zamiast Fi0 i tak 
% dalej wykorzystane zostaną wielomiany 
A = zeros(length(u),n);
%Cała pierwsza kolumna zostaje zapisana.
A(:,1) = 1;

%Zagnieżdżona pętla for w której w zależności od stopnia interpolacji
%wporwadzany są xy w odpowiedniej potędze. 
for i = 1:length(u)
    for j = 2:n
        A(i,j) = u(i)^(j-1);
    end
end

%Wspołczynniki wyliczane są z przekształcenia formy macierozwej ze wzoru
%6.2.7 z podręcznika
wsp = (A.'*A)\(A.'*M);
%Budowanie parametrycznie wielomianu
y = x*0 + wsp(1);
%Parametryczne budowanie wielomianu
for i = 2:n
    y = y + wsp(i)*x.^(i-1);
end

%petla for dla warunków if dla punktów nierównoloodłegłyhch na końcach
%przdziałów.
for i = 1:length(x)
    if y(i)>max(M)
        y(i) = max(M);
    end
    if y(i)<min(M)
        y(i) = min(M);
    end
end
end
 
 