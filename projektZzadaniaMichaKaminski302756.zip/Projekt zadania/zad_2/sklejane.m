%Funkcja pomocnicza dla interpolacji funkcjami sklejanymi pierwszego stopnia.
function y = sklejane(x)

%Tabela zależności indukcyjnosci od napięcia na cewce U1 
u = [20 50 100 150 200 250 280 300].';
M = [0.46 0.64 0.78 0.68 0.44 0.23 0.18 0.18].';

%Zainicjalizowanie na początku skłądający się z samych zer. 
y = x*0;

for i = 1:length(x)
    for j = 1:length(u)
        if x(i)<=u(j)
            break;
        end
        %Warunek gdy wartośc nie spełniona jest w żadnym warunku,
        %przypisywana jest wartość 30 aby mógł wykonać się ostatni if j==30
        j = 30;
    end
    if j == 1
        y(i) = M(1);
        continue;
    end
    if j == 30
        y(i) = M(end);
        continue;
    end
    % Jeśli żaden z powyższych warunków nie jest spełniony, to punkt x(i) 
    % znajduję się w zakresie interpolacji i wykorzystany zostanie 
    % wzór na interpolacje liniową
    y(i) = M(j-1)+(M(j)-M(j-1))/(u(j)-u(j-1))*(x(i)-u(j-1));
end
end
 
 
 
 