%W Funkcji pomocnieczej zamieszczony jest ostateczny układ równań zmiennych
%stanu zapisany w postaci macierzowej. 
function [dy] = poch2(y,t,p,rodzaj)

%zmienne pomocnicze, dla ułatwienia i przejrzystości zapisu wzoru, 
% wartości z głównej funkcji zad_1. podanne z treści zadania.  
R1 = p.R1;
R2 = p.R2;
C = p.C;
L1 = p.L1;
L2 = p.L2;

% instruckja switch, która określa jaki rodzaj funkcji zostanie wybrany w
% późniejszej części programu.
switch rodzaj
    case "a"
        pomoc = @(x) interpolacja(x);
    case "b"
        pomoc = @(x) sklejane(x);
    case "c"
        pomoc = @(x) aproksymacja(x,3);
    case "d"
        pomoc = @(x) aproksymacja(x,5);
end

%Zmodyfikowany układ równań wynikający z treści zadania
M = pomoc(abs(e(t,p.e) - y(3) - y(1)*R1));

D1 = L1/M - M/L2;
D2 = M/L1 - L2/M;

dy(1) = -R1/M/D1 * y(1) +R2/L2/D1 * y(2)  -1/M/D1 * y(3) +1/M/D1 * e(t,p.e);
dy(2) = -R1/L1/D2 * y(1) +R2/M/D2 * y(2)  -1/L1/D2 * y(3) +1/L1/D2 * e(t,p.e);
dy(3) = 1/C*y(1);

end

