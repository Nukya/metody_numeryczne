clear
close all
clc

%czas
t_k = 30;
%krok
h = 0.01;
%Tablice 
i_1 = [];
i_2 = [];
u_R2 = [];
u_c = [];

warning off;

%Głowna pętla wykonująca wszystkie wymuszenia
for wymuszenie = ['5','6']
    %Pętla która wykonuje wszystkei warunku dla wszystich rodzajów z
    %funkcji pomocniczej poch2.m
    for rodzaj = ["a" "b" "c" "d"]
        %Dane z treści zadania
        p.R1 = 0.1;
        p.R2 = 10;
        p.C = 0.5;
        p.L1 = 3;
        p.L2 = 5;
        p.M = 0.8;
        %określenie z jakim dla jakiego wymuszenia będzie 
        switch wymuszenie
            case '5'
                p.e = '5';
            case '6'
                p.e = '6';
        end
        %czas z krokiem
        t = [0:h:t_k];        
        
        y_ul = zeros(length(t),3);
        
        %obliczenia pochodnej wraz z rodzajem wynikające z treści zadania
        for i = 1:(length(t)-1)
            pomoc = y_ul(i,:) + h/2*poch2(y_ul(i,:),t(i),p,rodzaj);
            y_ul(i+1,:) = y_ul(i,:) + h*poch2(pomoc,t(i)+h/2,p,rodzaj);
        end
        %Zapis wartości do Tablic.
        i_1 = [i_1,y_ul(:,1)];
        i_2 = [i_2,y_ul(:,2)];
        u_R2 = [u_R2,y_ul(:,2)*p.R2];
        u_c = [u_c,y_ul(:,3)];                
    end    
end

% Wykreslanie wykresów dla 240*sin(2*t)
figure;
hold on;
title("Natężenie i_1 [A] dla wym. 240*sin(2*t)");
for i = 1:4
    plot(t,i_1(:,i));
end
legend(["interpolacja","sklejane","aproksymacja st. 3","aproksymacja st. 5"])
ylabel('I[A]');
xlabel('t(s)');
hold off;
saveas(gca,['i_1_wym_5.png']);


figure;
hold on;
title("Natężenie i_2 [A] dla wym. 240*sin(2*t)");
for i = 1:4
    plot(t,i_2(:,i));
end
legend(["interpolacja","sklejane","aproksymacja st. 3","aproksymacja st. 5"])
ylabel('I[A]');
xlabel('t(s)');
hold off;
saveas(gca,['i_2_wym_5.png']);

figure;
hold on;
title("Napięcie u_{R2} [A] dla wym. 240*sin(2*t)");
for i = 1:4
    plot(t,u_R2(:,i));
end
legend(["interpolacja","sklejane","aproksymacja st. 3","aproksymacja st. 5"])
ylabel('U[V]');
xlabel('t(s)');
hold off;
saveas(gca,['u_R2_wym_5.png']);


figure;
hold on;
title("Napięcie u_C [A] dla wym. 240*sin(2*t)");
for i = 1:4
    plot(t,u_c(:,i));
end
legend(["interpolacja","sklejane","aproksymacja st. 3","aproksymacja st. 5"])
ylabel('U[V]');
xlabel('t(s)');
hold off;
saveas(gca,['u_c_wym_5.png']);




% Wykreslanie wykresów dla 120*sin(2*t)

figure;
hold on;
title("Natężenie i_1 [A] dla wym. 120*sin(2*t)");
for i = 5:8
    plot(t,i_1(:,i));
end
legend(["interpolacja","sklejane","aproksymacja st. 3","aproksymacja st. 5"])
ylabel('I[A]');
xlabel('t(s)');
hold off;
saveas(gca,['i_1_wym_6.png']);


figure;
hold on;
title("Natężenie i_2 [A] dla wym. 120*sin(2*t)");
for i = 5:8
    plot(t,i_2(:,i));
end
legend(["interpolacja","sklejane","aproksymacja st. 3","aproksymacja st. 5"])
ylabel('I[A]');
xlabel('t(s)');
hold off;
saveas(gca,['i_2_wym_6.png']);

figure;
hold on;
title("Napięcie u_{R2} [A] dla wym. 120*sin(2*t)");
for i =  5:8
    plot(t,u_R2(:,i));
end
legend(["interpolacja","sklejane","aproksymacja st. 3","aproksymacja st. 5"])
ylabel('U[V]');
xlabel('t(s)');
hold off;
saveas(gca,['u_R2_wym_6.png']);


figure;
hold on;
title("Napięcie u_C [A] dla wym. 120*sin(2*t)");
for i = 5:8
    plot(t,u_c(:,i));
end
legend(["interpolacja","sklejane","aproksymacja st. 3","aproksymacja st. 5"])
ylabel('U[V]');
xlabel('t(s)');
hold off;
saveas(gca,['u_c_wym_6.png']);


