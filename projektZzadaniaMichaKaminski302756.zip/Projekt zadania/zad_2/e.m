%Funkcja pomocnicza w której za pomocą instrukcji switch zapisane są
%wszystkie wymuszenia potrzebne do do wykreślenia wykresów w zad_2. Funkcja
%ta zwraca zmienna u dla poszczególnych wymuszeń w zależności od warunku.

function [u] = e(t,ee)

switch ee
    case '1'
        u = 60+60*square(t*2*pi/3);
    case '2'
        u = 240*sin(t);
    case '3'
        u = 210*sin(2*pi*5*t);
    case '4'
        u = 120*sin(2*pi*50*t);
    case '5'
        u = 240*sin(2*t);
    case '6'
        u = 120*sin(2*t);
    otherwise
        u = NaN;        
end
end

